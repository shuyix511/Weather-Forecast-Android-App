package com.example.thinkpad.myapplication;

/**
 * Created by Thinkpad on 2015/12/10.
 */
public class MapActivity {
}
